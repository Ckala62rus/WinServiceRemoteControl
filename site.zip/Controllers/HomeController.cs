﻿using Hangfire;
using HangFire.Models;
using Microsoft.AspNetCore.Http.Connections;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Management;
using System.ServiceProcess;
using System.Threading.Tasks;

namespace HangFire.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly UserManager<IdentityUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;

        public HomeController(
            ILogger<HomeController> logger,
            UserManager<IdentityUser> userManager,
            RoleManager<IdentityRole> roleManager
        )
        {
            _logger = logger;
            _userManager = userManager;
            _roleManager = roleManager;
        }

        /// <summary>
        /// 
        /// Add role admin for user
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task<IActionResult> AddUserToAdminRole()
        {
            // Создание роли
            await _roleManager.CreateAsync(new IdentityRole("HangfireAdmin"));

            //Поиск ползователя по Имени (почте)
            var user = await _userManager.FindByNameAsync("agr.akyla@mail.ru");

            // Привязка пользователя к роли
            await _userManager.AddToRoleAsync(user, "HangfireAdmin");

            return Ok();
        }

        public IActionResult Index()
        {
            //ServiceController[] sc = ServiceController.GetServices("pc-6969");
            //            ServiceController svc = new ServiceController("Центр обновления Windows", "rk-dax-app-prd");
            ServiceController svc = new ServiceController("Центр обновления Windows", "rk-dax-app-prd");

            //foreach (var s in sc)
            //{
            //    Services.Add(new Service { Name = s.ServiceName, Running = s.Status == ServiceControllerStatus.Running });
            //}
            //return Services;


            //bool name = User.IsInRole("HangfireAdmin"); // Есть ли у пользователя роль
            //var user = User.Identity.Name; // Имя пользователя

            //RecurringJob.AddOrUpdate("The first job", () => Console.WriteLine("First"), "* * * * *");
            //RecurringJob.AddOrUpdate("The second job", () => Console.WriteLine("Second"), "* * * * *");
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
